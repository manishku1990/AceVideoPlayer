# Ace Video Player — starter project

Ad-free, local-first Android video player starter using LibVLC, with a Google Cast sender button and a temporary LAN HTTP endpoint for a user-selected video.

## Build from an Android phone (free cloud build)

1. Download and extract `AceVideoPlayer-Starter.zip` on your phone (Files app or ZArchiver).
2. In a browser, create a new **public** GitHub repository named `AceVideoPlayer` (public repo is simplest for free GitHub Actions). Do not add a README/license/gitignore during creation.
3. Open the repository in GitHub mobile browser and use **Add file → Upload files**. Upload the *contents* of the extracted folder, including the hidden `.github/workflows/build-apk.yml` file. If the GitHub mobile UI hides `.github`, use the browser's Desktop site or GitHub web editor to create `.github/workflows/build-apk.yml` with the included file contents.
4. Commit to `main`. Open the repository's **Actions** tab and select **Build Ace Video Player APK** if needed, then **Run workflow**.
5. When the workflow finishes green, open the run, scroll to **Artifacts**, and download `AceVideoPlayer-debug-apk`. Extract it and install `app-debug.apk`. Android may ask you to allow installs from that browser/file manager.

## Local build (if a computer becomes available)

Open this folder in Android Studio and run the `app` configuration, or run `gradle wrapper --gradle-version 8.9` then `./gradlew assembleDebug`.

## Casting notes

- Phone and Chromecast/Google TV should be on the same Wi-Fi network.
- The app uses Google's Default Media Receiver ID, so it does not require a custom receiver app ID or API key.
- Android's INTERNET permission is required for the local LAN HTTP server; this starter has no analytics, ad SDK, account system, or intentional remote streaming service. Gradle needs internet during the build to download open-source dependencies.
- This is a starter project, not yet a production-ready MX Player replacement. Test casting on the actual TV. Certain codecs may play on the phone but not on the Cast receiver. A robust production version should add tokenized LAN URLs, lifecycle-safe foreground service handling, and more exhaustive range/seek tests.

## License note

LibVLC is open source, but redistribution and licensing obligations must be reviewed before public distribution. See VideoLAN's official Android project and license notices: https://github.com/videolan/vlc-android
