package com.ace.videoplayer

object NanoHttpdCompat {
    const val SOCKET_READ_TIMEOUT = 10_000
}
