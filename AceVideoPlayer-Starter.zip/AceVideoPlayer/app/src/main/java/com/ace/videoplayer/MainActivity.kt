package com.ace.videoplayer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {
    private lateinit var surface: SurfaceView
    private lateinit var status: TextView
    private lateinit var fileName: TextView
    private lateinit var emptyText: TextView
    private var selectedUri: Uri? = null
    private var libVlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private var castContext: CastContext? = null
    private var mediaServer: LocalMediaServer? = null

    private val sessionListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarted(session: CastSession, sessionId: String) = castSelectedVideo(session)
        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) = castSelectedVideo(session)
        override fun onSessionEnded(session: CastSession, error: Int) { stopServer(); status.text = "Cast disconnected • Offline mode" }
        override fun onSessionStartFailed(session: CastSession, error: Int) { status.text = "Unable to connect to Cast device" }
        override fun onSessionEnding(session: CastSession) {}
        override fun onSessionResuming(session: CastSession, sessionId: String) {}
        override fun onSessionResumeFailed(session: CastSession, error: Int) {}
        override fun onSessionStarting(session: CastSession) { status.text = "Connecting to TV…" }
        override fun onSessionSuspended(session: CastSession, reason: Int) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        surface = findViewById(R.id.videoSurface)
        status = findViewById(R.id.statusText)
        fileName = findViewById(R.id.fileName)
        emptyText = findViewById(R.id.emptyText)
        surface.holder.addCallback(this)

        findViewById<Button>(R.id.selectButton).setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "video/*"
            }
            startActivityForResult(intent, REQUEST_VIDEO)
        }
        findViewById<Button>(R.id.playButton).setOnClickListener { playOnPhone() }
        try {
            castContext = CastContext.getSharedInstance(this)
            castContext?.sessionManager?.addSessionManagerListener(sessionListener, CastSession::class.java)
            CastButtonFactoryCompat.setup(this, findViewById(R.id.castButton))
        } catch (e: Exception) {
            status.text = "Cast unavailable: check Google Play services"
        }
    }

    private fun playOnPhone() {
        val uri = selectedUri ?: run { status.text = "Choose a video first"; return }
        try {
            if (libVlc == null) {
                val engine = LibVLC(this, arrayListOf("--no-video-title-show"))
                libVlc = engine
                player = MediaPlayer(engine)
                player?.vlcVout?.setVideoView(surface)
                player?.vlcVout?.attachViews()
            }
            val media = Media(libVlc ?: return, uri)
            player?.media = media
            media.release()
            player?.play()
            emptyText.visibility = View.GONE
            status.text = "Playing locally • No ads"
        } catch (e: Exception) {
            status.text = "Could not play this file: ${e.message ?: "unsupported format"}"
        }
    }

    private fun castSelectedVideo(session: CastSession) {
        val uri = selectedUri ?: run { status.text = "TV connected. Choose a video to cast."; return }
        try {
            stopServer()
            val server = LocalMediaServer(contentResolver, uri)
            server.start(NanoHttpdCompat.SOCKET_READ_TIMEOUT, false)
            mediaServer = server
            val ip = findLocalIpv4() ?: run { status.text = "Connect phone and TV to same Wi-Fi"; stopServer(); return }
            val url = "http://$ip:${server.listeningPort}/video"
            val mime = contentResolver.getType(uri) ?: "video/mp4"
            val title = getDisplayName(uri)
            val mediaInfo = MediaInfo.Builder(url).setContentType(mime).setStreamType(MediaInfo.STREAM_TYPE_BUFFERED).setMetadata(
                com.google.android.gms.cast.MediaMetadata(com.google.android.gms.cast.MediaMetadata.MEDIA_TYPE_MOVIE).apply { putString(com.google.android.gms.cast.MediaMetadata.KEY_TITLE, title) }
            ).build()
            val request = MediaLoadRequestData.Builder().setMediaInfo(mediaInfo).setAutoplay(true).build()
            session.remoteMediaClient?.load(request)
            emptyText.visibility = View.VISIBLE
            status.text = "Casting to TV • Local Wi-Fi only"
        } catch (e: Exception) {
            stopServer()
            status.text = "Cast error: ${e.message ?: "try again"}"
        }
    }

    private fun findLocalIpv4(): String? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val intf = interfaces.nextElement()
                val addresses = intf.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address && intf.isUp) return addr.hostAddress
                }
            }
        } catch (_: Exception) {}
        return null
    }

    private fun getDisplayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "Local video"
        }
        return "Local video"
    }

    private fun stopServer() {
        try { mediaServer?.stop() } catch (_: Exception) {}
        mediaServer = null
    }

    @Deprecated("Deprecated in Android API; retained for broad device support")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VIDEO && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                selectedUri = uri
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                fileName.text = getDisplayName(uri)
                status.text = "Video selected • Ready to play or cast"
                if (castContext?.sessionManager?.currentCastSession?.isConnected == true) castSelectedVideo(castContext!!.sessionManager.currentCastSession!!)
            }
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        player?.vlcVout?.setVideoView(surface)
        player?.vlcVout?.attachViews()
    }
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
    override fun surfaceDestroyed(holder: SurfaceHolder) { player?.vlcVout?.detachViews() }

    override fun onDestroy() {
        castContext?.sessionManager?.removeSessionManagerListener(sessionListener, CastSession::class.java)
        stopServer()
        player?.release(); player = null
        libVlc?.release(); libVlc = null
        super.onDestroy()
    }

    companion object { private const val REQUEST_VIDEO = 1001 }
}
