package com.ace.videoplayer

import android.content.Context
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.framework.CastButtonFactory

object CastButtonFactoryCompat {
    fun setup(context: Context, button: MediaRouteButton) {
        CastButtonFactory.setUpMediaRouteButton(context, button)
    }
}
