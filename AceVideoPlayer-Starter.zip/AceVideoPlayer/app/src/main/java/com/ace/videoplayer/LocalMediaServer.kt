package com.ace.videoplayer

import android.content.ContentResolver
import android.net.Uri
import android.webkit.MimeTypeMap
import fi.iki.elonen.NanoHTTPD
import java.io.InputStream

/** Serves only the user-selected content URI over the local network while casting. */
class LocalMediaServer(
    private val resolver: ContentResolver,
    private val videoUri: Uri,
    port: Int = 8765
) : NanoHTTPD(port) {
    override fun serve(session: IHTTPSession): Response {
        if (session.uri != "/video") return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
        return try {
            val afd = resolver.openAssetFileDescriptor(videoUri, "r")
                ?: return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "File unavailable")
            val totalLength = afd.length
            val mime = resolver.getType(videoUri) ?: "application/octet-stream"
            val range = session.headers["range"]
            var start = 0L
            var end = if (totalLength > 0) totalLength - 1 else -1L
            if (range != null && totalLength > 0 && range.startsWith("bytes=")) {
                val parts = range.removePrefix("bytes=").split("-", limit = 2)
                start = parts[0].toLongOrNull() ?: 0L
                end = parts.getOrNull(1)?.toLongOrNull() ?: end
                if (start > end || start >= totalLength) {
                    afd.close()
                    return newFixedLengthResponse(Response.Status.RANGE_NOT_SATISFIABLE, "text/plain", "Invalid range")
                }
                end = minOf(end, totalLength - 1)
            }
            val input: InputStream = afd.createInputStream()
            var skipped = 0L
            while (skipped < start) {
                val n = input.skip(start - skipped)
                if (n <= 0) break
                skipped += n
            }
            val length = if (totalLength > 0) end - start + 1 else -1L
            val status = if (range != null && totalLength > 0) Response.Status.PARTIAL_CONTENT else Response.Status.OK
            val response = if (length >= 0) newFixedLengthResponse(status, mime, input, length) else newChunkedResponse(status, mime, input)
            response.addHeader("Accept-Ranges", "bytes")
            response.addHeader("Access-Control-Allow-Origin", "*")
            if (status == Response.Status.PARTIAL_CONTENT) response.addHeader("Content-Range", "bytes $start-$end/$totalLength")
            response
        } catch (e: Exception) {
            newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", "Unable to serve video")
        }
    }
}
